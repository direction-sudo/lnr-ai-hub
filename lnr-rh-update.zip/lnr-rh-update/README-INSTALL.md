# Mise à jour Leo RH Module

## Fichiers à copier dans votre projet local

### 1. Nouveaux fichiers (créer)
- `api/rh-router.ts` → dossier `api/`
- `db/relations.ts` → dossier `db/`
- `src/hooks/useRH.ts` → dossier `src/hooks/`
- `src/pages/RHPage.tsx` → dossier `src/pages/`

### 2. Fichiers à remplacer (écraser)
- `api/router.ts` → ajoute `rh: rhRouter`
- `db/schema.ts` → ajoute 6 tables RH
- `src/pages/DashboardPage.tsx` → ajoute route /rh + menu
- `src/providers/trpc.tsx` → ajoute mocks RH

## Commandes après copie

```bash
cd votre-projet-lnr-ai-hub

# Copier les fichiers (Linux/Mac)
cp -r /chemin/vers/lnr-rh-update/* .

# Ou manuellement avec Explorer/Finder
# - Glisser-déposer les fichiers aux bons endroits

# Build
npm run build

# Test
npm run dev

# Push sur GitHub
git add -A
git commit -m "feat: Leo RH module - 10 fonctionnalités"
git push origin main
```
